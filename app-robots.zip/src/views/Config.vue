<template>
  <v-main>
    <!-- <router-link to="/">HOME</router-link> -->
    <v-card elevation="3" class="ma-5">
      <form class="pa-5">
        <v-text-field
          v-model="name"
          label="Local de Instalação do Chrome"
        ></v-text-field>
        <v-btn> enviar </v-btn>
        <v-btn class="mx-3">
          <router-link to="/" tag="span" class="">voltar</router-link>
        </v-btn>
      </form>
    </v-card>
  </v-main>
</template>

<script>
export default {
  name: "config",

  data() {
    return {
      name: null,
    };
  },
};
</script>

<style>
</style>